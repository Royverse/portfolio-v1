# Roy's Atelier Studio Edition — 60-Second Setup Guide (macOS & Windows)

Welcome to **Roy's Atelier Studio Edition**. This companion pack allows you to play 5 rare spatial instruments in your browser and route 10 continuous kinematic axes directly into your DAW with zero optical jitter.

---

## 1. Virtual MIDI Routing in 60 Seconds

### macOS (Zero Software Required — Native IAC Driver)
1. Open **Audio MIDI Setup** (Press `Cmd + Space`, type `Audio MIDI Setup`, hit Return).
2. Press `Cmd + 2` to open the **MIDI Studio** window.
3. Double-click the red **IAC Driver** icon.
4. Check **"Device is online"**.
5. In Roy's Atelier web tab, open **DAW MIDI** and select **"IAC Driver Bus 1"**.

### Windows (Free loopMIDI Utility)
1. Download and run **loopMIDI** from Tobias Erichsen (`tobias-erichsen.de/software/loopmidi.html`).
2. Click the **[+]** button to create a virtual port named `loopMIDI Port`.
3. In Roy's Atelier web tab, open **DAW MIDI** and select **"loopMIDI Port"**.

---

## 2. DAW Macro Mapping with [SOLO MAP]

When assigning multi-axis controllers in Ableton Live (`Cmd + M`) or FL Studio (`Ctrl + J`), all 10 axes can broadcast at once.
Roy's Atelier eliminates this with single-axis **`[SOLO MAP]`**:

1. In the Roy's Atelier **DAW MIDI** drawer, click **`[SOLO MAP]`** next to the axis you want to assign (e.g. `Right Hand Y (CC 74)`).
2. All other 9 axes are instantly muted.
3. In your DAW, click your cutoff or reverb macro.
4. Move your right hand vertically — it binds cleanly in 1 second.
5. Click **`[SOLO MAP]`** again to return all axes to live performance mode.

---

## 3. Kinematic Axis Map

| Hand & Axis | MIDI Channel | Output Type | Default Assignment |
| :--- | :--- | :--- | :--- |
| **Right Hand X** | Channel 1 | 14-Bit Pitchbend (16,384 steps) + CC 16 | Continuous Ribbon Glissando / Pitch |
| **Right Hand Y** | Channel 1 | CC 74 | MPE Brightness / Cutoff |
| **Right Hand Z** | Channel 1 | CC 17 | Spatial Depth / Reverb Wet |
| **Right Pinch** | Channel 1 | CC 1 + NoteOn Gate | Touche d'intensité / Mod Wheel |
| **Right Roll** | Channel 1 | CC 18 | Wrist Timbre Tilt |
| **Left Hand X** | Channel 2 | CC 20 | Macro 1 / Stereo Pan |
| **Left Hand Y** | Channel 2 | CC 11 | Master Expression / Volume Loop |
| **Left Hand Z** | Channel 2 | CC 21 | Spatial Depth / Decay |
| **Left Pinch** | Channel 2 | CC 22 | Harmonic Drive / Freeze |
| **Left Roll** | Channel 2 | CC 23 | Wrist Roll / Voicing Morph |

---

## 4. Included Files
- `01_Rare_Instrument_WAV_Stems_24bit_48k/`: 40 broadcast-ready WAV stems for hardware samplers (Digitakt, Octatrack, SP-404, MPC).
- `02_DAW_Templates_and_M4L/Roys_Atelier_Macro_Bridge.als`: Pre-routed 2-track Ableton Live 11/12 template.
- `02_DAW_Templates_and_M4L/Roys_Atelier_Receiver.amxd`: Max for Live parameter mapper device.
